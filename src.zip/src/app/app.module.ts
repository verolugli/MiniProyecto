import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { PokedexService } from './pokedex.service';
import { DescripcionComponent } from './descripcion/descripcion.component';
import { InformacionComponent } from './informacion/informacion.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    DescripcionComponent,
    InformacionComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot([
      {
        path: 'informacion',
        component: InformacionComponent
      }
    ])

  ],
  providers: [
    PokedexService,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
